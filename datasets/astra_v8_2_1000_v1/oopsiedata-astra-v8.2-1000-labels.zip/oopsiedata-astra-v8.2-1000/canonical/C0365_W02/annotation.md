# Episode: C0365_W02

## Episode annotation

- Language task: Clean the table by placing the cans in the upper tray and the bowls in the tray on the right.
- Success label: failure
- Outcome evidence: Completion is unconfirmed in this window, not a visibly failed attempt. In base_image frames 350–650, the gripper approaches and closes around the green can; in frames 667–699, the can moves with the gripper toward the upper blue tray, indicating acquisition and task-directed transport. At frame 699, no placement is yet visible, both bowls remain outside the right red tray, and the other can remains on the table. No local failure is established. Earlier context is limited to frames 348–349, and later execution is not supplied; this outcome is provisional.

## Timeline

| Start frame | End frame | Failure |
| --- | --- | --- |
| 350 | 700 | No |

## Failure annotations

None